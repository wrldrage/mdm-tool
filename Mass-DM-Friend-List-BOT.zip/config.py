token="ODA0NTMzNDUxMjI2NDgwNjY3.YD5T8Q.fHsf9mwTehnQPyU-ox7ee_I_bqM"
# TOKEN ^^^
dm_message="me cock W"
# DM MESSAGE ^^^ ; use \n to go next line
